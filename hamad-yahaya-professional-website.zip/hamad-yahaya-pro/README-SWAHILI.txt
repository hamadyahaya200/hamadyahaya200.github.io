HAMAD YAHAYA WEBSITE — UPLOAD GUIDE

1. Extract this ZIP on your computer.
2. Open the extracted folder hamad-yahaya-pro.
3. Open your GitHub repository: hamadyahaya200.github.io
4. Upload index.html and the complete assets folder to the repository ROOT.
5. If GitHub asks whether to replace existing files, confirm replacement.
6. Commit changes to the main branch.
7. Wait for GitHub Pages to finish, then open https://hamadyahaya200.github.io/

IMPORTANT:
- index.html and assets must be at the same repository level.
- Do not upload the outer ZIP file itself.
- The website shows the field report and proposal as page images in an on-page reader. This discourages direct downloading but cannot prevent screenshots or copying.
- Change the email in index.html if you want a different public contact address.
